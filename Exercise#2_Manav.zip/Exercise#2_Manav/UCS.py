
from State import State
from Node import Node
import queue
from TreePlot import TreePlot

def performUCS():
    """
    This method performs Uniform Cost search
    """
    
    #create queue
    pqueue = queue.PriorityQueue()
    visited = []  # Using a list for visited nodes

    # Create the initial state and root node
    initialState = State("Bus Stop")  # Starting node (example)
    root = Node(initialState, None)
    root.costFromRoot = 0  # Assuming the initial cost is zero

    # Add root to visited and priority queue
    visited.append(root.state.place)  # Mark the root as visited
    pqueue.put((root.costFromRoot, root))


    
    #check if there is something in priority queue to dequeue
    while not pqueue.empty(): 
        
        #dequeue nodes from the priority Queue
        _, currentNode = pqueue.get()
        
        #remove from the fringe
        currentNode.fringe = False

        treeplot = TreePlot()
        treeplot.generateDiagram(root, currentNode)


        #check if it has goal State
        print ("-- dequeue --", currentNode.state.place)
        
        #check if this is goal state
        if currentNode.state.checkGoalState():
            print ("reached goal state")
            #print the path
            print ("----------------------")
            print ("Path")
            currentNode.printPath()
            
            #show the search tree explored so far
            treeplot = TreePlot()
            treeplot.generateDiagram(root, currentNode)
            break
            
        #get the child nodes 
        childStates = currentNode.state.successorFunction()
        for childState in childStates:

            if childState not in visited:
                childNode = Node(State(childState), currentNode)
                # add to tree and queue
                pqueue.put((childNode.costFromRoot, childNode))
                visited.append(childState)

    #print tree
    print ("----------------------")
    print ("Tree")
    root.printTree()
    
performUCS()