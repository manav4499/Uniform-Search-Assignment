from GraphData import *

class State:
    '''
    This class retrieves state information for social connection feature
    '''
    
    def __init__(self, name = None):
        if name == None:
            #create initial state
            self.name = self.getInitialState()
        else:
            self.name = name

    def getInitialState(self):
        """
        This method returns me.
        """
        initialState = "Adam"
        return initialState


    def successorFunction(self, graphName):
        """
        This is the successor function. It finds all the persons connected to the
        current person
        """
        return graphName[self.name]
        
        
    def checkGoalState(self, endName = "Manav"):
        """
        This method checks whether the person is the target person .
        """ 
        #check if the person's name is Manav
        return self.name == endName