#create a dictionary with all the mappings
graphs = {
    "connections" : {
    "Adam": {"Manav"},
    "Manav": {"Ema", "George", "Bob"},
    "Ema": {"Manav", "George"},
    "Bob": {"Manav", "George", "Dolly", "Jim"},
    "George": {"Ema", "Manav", "Bob", "Frank"},
    "Frank": {"George"},
    "Dolly": {"Bob"},
    "Jim": {"Bob"}
},

}


