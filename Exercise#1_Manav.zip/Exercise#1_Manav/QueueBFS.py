from Node import Node
from State import State
from collections import deque
from GraphData import graphs

def BFS_Manav(graph_name, Start, End):
    """
    This function performs BFS search using a queue to find the shortest path between two nodes.
    """

    # Check if the graph exists
    if graph_name in graphs:
        graph = graphs[graph_name]
    else:
        print("Graph not found!")
        return

    # Check if the start and end names exist in the graph
    if Start not in graph:
        print("Start name does not exist in the graph!")
        return
    elif End not in graph:
        print("End name does not exist in the graph!")
        return

    # Initialize queue and visited list
    queue = deque([])
    visited = []  # Using a list for visited nodes

    # Create the root node and add to queue and visited
    root = Node(State(Start))
    queue.append(root)
    visited.append(Start)

    # Perform BFS
    while queue:
        currentNode = queue.popleft()
        print("-- dequeue --", currentNode.state.name)

        # Check if goal state is reached
        if currentNode.state.checkGoalState(End):
            print("Reached goal state!")
            print("----------------------")
            print("Path:")
            currentNode.printPath()
            break

        # Explore child nodes
        childStates = currentNode.state.successorFunction(graph)
        for childState in childStates:

            if childState not in visited:
                # Create a child node and add it to the tree, queue, and visited list
                childNode = Node(State(childState))
                currentNode.addChild(childNode)
                queue.append(childNode)
                visited.append(childState)

    # Print tree
    print("----------------------")
    print("Tree:")
    root.printTree()

# Example calls based on the assignment requirements
BFS_Manav("connections", "Dolly", "Manav")
BFS_Manav("connections", "Frank", "Dolly")
